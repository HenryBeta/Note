﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyKeibaDemo
{
    class RaceInfo
    {
        public string race_date { get; set; }
        public string race_number { get; set; }
        public string race_distance { get; set; }
        public string race_starttime { get; set; }
        public string race_weather { get; set; }
        public string race_condition { get; set; }
        public string race_prize { get; set; }
    }
}
