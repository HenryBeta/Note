﻿using HtmlAgilityPack;
using System.Text;

namespace MyKeibaDemo
{
    class CHttpConnection
    {
        public static HtmlDocument OpenRequest(string race_day,
                                        string operation_track_code,
                                        string sponsor_code,
                                        string race_number,
                                        string view_type,
                                        string bet_type)
        {

            //string url = "http://www.oddspark.com/keiba/Odds.do?raceDy=20141129&opTrackCd=12&sponsorCd=06&raceNb=1&viewType=0&betType=1";
            //string url = BuildUrl(race_day, operation_track_code, sponsor_code, race_number, view_type, bet_type);

            StringBuilder url = new StringBuilder();
            url.Append("http://www.oddspark.com/keiba/Odds.do?");
            url.Append("raceDy=" + race_day + "&");
            url.Append("opTrackCd=" + operation_track_code + "&");
            url.Append("sponsorCd=" + sponsor_code + "&");
            url.Append("raceNb=" + race_number + "&");
            url.Append("viewType=" + view_type + "&");
            url.Append("betType=" + bet_type);

            HtmlWeb htmlweb = new HtmlWeb();
            HtmlDocument htmldocument = htmlweb.Load(url.ToString());
            return htmldocument;
        }
    }
}
