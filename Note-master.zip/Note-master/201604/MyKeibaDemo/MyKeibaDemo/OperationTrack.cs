﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyKeibaDemo
{
    class OperationTrack
    {

        public static string CatchWinData(string race_day, string operation_track_code, string sponsor_code)
        {
            StringBuilder data = new StringBuilder();
            data.AppendLine("r0,r123,r710-t4,r710-t3,r710-t2,r710-t1,r710,r710+t1,r710+t2,r710+t3,r710+t4");
            for (int i = 1; i <= 12; i++)
            {
                HtmlDocument htmldoc = CHttpConnection.OpenRequest(race_day, operation_track_code, sponsor_code, i.ToString(), "0", "1");
                HtmlNode table = htmldoc.DocumentNode.SelectSingleNode("//html//table[@summary='単勝・複勝']");
                if (table != null)
                {


                    List<string> winodds = CHtmlResolver.GetWinOdds(htmldoc);
                    for (int j = 0; j < winodds.Count; j++)
                    {
                        data.AppendLine("r" + race_day + i.ToString("00") + "," + (j+1).ToString() + ","  +",,,,"+ winodds[j] + "," + ",,,");
                    }
                }
            }

            return data.ToString();
        }

        public static string CatchPlaceShowData(string race_day, string operation_track_code, string sponsor_code)
        {
            StringBuilder data = new StringBuilder();
            data.AppendLine("r0,r123,r720-t4,r720-t3,r720-t2,r720-t1,r720,r720+t1,r720+t2,r720+t3,r720+t4");
            for (int i = 1; i <= 12; i++)
            {
                HtmlDocument htmldoc = CHttpConnection.OpenRequest(race_day, operation_track_code, sponsor_code, i.ToString(), "0", "1");
                HtmlNode table = htmldoc.DocumentNode.SelectSingleNode("//html//table[@summary='単勝・複勝']");
                if (table != null)
                {
                    

                    List<string> placeshowodds = CHtmlResolver.GetPlaceShowOdds(htmldoc);
                    for (int k = 0; k < placeshowodds.Count; k++)
                    {
                        data.AppendLine("r" + race_day + i.ToString("00") + "," + (k + 1).ToString() + "," + ",,,," + placeshowodds[k] + "," + ",,,");
                    }

                }
            }

            return data.ToString();
        }

        public static string CatchBracketQuinellaData(string race_day, string operation_track_code, string sponsor_code)
        {
            StringBuilder data = new StringBuilder();
            data.AppendLine("r0,r123,r730-t4,r730-t3,r730-t2,r730-t1,r730,r730+t1,r730+t2,r730+t3,r730+t4");
            for (int i = 1; i <= 12; i++)
            {
                HtmlDocument htmldoc = CHttpConnection.OpenRequest(race_day, operation_track_code, sponsor_code, i.ToString(), "0", "1");
                HtmlNode table3 = htmldoc.DocumentNode.SelectSingleNode("//html//table[@summary='枠複']");
                if (table3 != null)
                {
                    List<string> bracketquinellaodds = CHtmlResolver.GetBracketQuinellaOdds(htmldoc);
                    int m = bracketquinellaodds.Count;

                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "1_1" + "," + ",,,," + bracketquinellaodds[0] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "1_2" + "," + ",,,," + bracketquinellaodds[4] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "1_3" + "," + ",,,," + bracketquinellaodds[8] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "1_4" + "," + ",,,," + bracketquinellaodds[12] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "1_5" + "," + ",,,," + bracketquinellaodds[16] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "1_6" + "," + ",,,," + bracketquinellaodds[20] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "1_7" + "," + ",,,," + bracketquinellaodds[23] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "1_8" + "," + ",,,," + bracketquinellaodds[25] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "2_2" + "," + ",,,," + bracketquinellaodds[1] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "2_3" + "," + ",,,," + bracketquinellaodds[5] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "2_4" + "," + ",,,," + bracketquinellaodds[9] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "2_5" + "," + ",,,," + bracketquinellaodds[13] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "2_6" + "," + ",,,," + bracketquinellaodds[17] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "2_7" + "," + ",,,," + bracketquinellaodds[21] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "2_8" + "," + ",,,," + bracketquinellaodds[24] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "3_3" + "," + ",,,," + bracketquinellaodds[2] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "3_4" + "," + ",,,," + bracketquinellaodds[6] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "3_5" + "," + ",,,," + bracketquinellaodds[10] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "3_6" + "," + ",,,," + bracketquinellaodds[14] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "3_7" + "," + ",,,," + bracketquinellaodds[18] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "3_8" + "," + ",,,," + bracketquinellaodds[22] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "4_4" + "," + ",,,," + bracketquinellaodds[3] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "4_5" + "," + ",,,," + bracketquinellaodds[7] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "4_6" + "," + ",,,," + bracketquinellaodds[11] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "4_7" + "," + ",,,," + bracketquinellaodds[15] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "4_8" + "," + ",,,," + bracketquinellaodds[19] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "5_5" + "," + ",,,," + bracketquinellaodds[26] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "5_6" + "," + ",,,," + bracketquinellaodds[28] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "5_7" + "," + ",,,," + bracketquinellaodds[31] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "5_8" + "," + ",,,," + bracketquinellaodds[35] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "6_6" + "," + ",,,," + bracketquinellaodds[27] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "6_7" + "," + ",,,," + bracketquinellaodds[30] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "6_8" + "," + ",,,," + bracketquinellaodds[34] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "7_7" + "," + ",,,," + bracketquinellaodds[29] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "7_8" + "," + ",,,," + bracketquinellaodds[33] + "," + ",,,");
                    data.AppendLine("r" + race_day + i.ToString("00") + "," + "8_8" + "," + ",,,," + bracketquinellaodds[32] + "," + ",,,");

                }
            }

            return data.ToString();
        }
    }
}
