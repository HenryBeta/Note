﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyKeibaDemo
{
    class CHtmlResolver
    {

        public static RaceInfo GetRaceInfo(HtmlDocument htmldoc)
        {
            HtmlNode div = htmldoc.DocumentNode.SelectSingleNode("//html//div[@id='RCdata2']");

            RaceInfo raceinfo = new RaceInfo();
            raceinfo.race_date = DeleteCrlfTabNbsp(div.SelectSingleNode("//li[@class='RCdate']").InnerText);
            raceinfo.race_number = DeleteCrlfTabNbsp(div.SelectSingleNode("//li[@class='RCnum']").InnerText);
            raceinfo.race_distance = DeleteCrlfTabNbsp(div.SelectSingleNode("//li[@class='RCdst']").InnerText);
            raceinfo.race_starttime = DeleteCrlfTabNbsp(div.SelectSingleNode("//li[@class='RCstm']").InnerText);
            raceinfo.race_weather = DeleteCrlfTabNbsp(div.SelectSingleNode("//li[@class='RCwthr']").InnerText);
            raceinfo.race_condition = DeleteCrlfTabNbsp(div.SelectSingleNode("//li[@class='RCcnd']").InnerText);
            raceinfo.race_prize = DeleteCrlfTabNbsp(div.SelectSingleNode("//p").InnerText);
            return raceinfo;
        }

        public static List<string> GetWinOdds(HtmlDocument htmldoc)
        {
            HtmlNode table = htmldoc.DocumentNode.SelectSingleNode("//html//table[@summary='単勝・複勝']");
            //HtmlNode table = htmldoc.DocumentNode.SelectSingleNode("/html[1]/body[1]/div[1]/div[3]/div[6]/div[1]/table[1]");
            HtmlNodeCollection tds = table.SelectNodes("//td[@class='al-center']");

            if (tds != null)
            {
                int count = tds.Count;

                // 単勝
                List<string> win_odds = new List<string>();
                for (int i = 0; i < count; i = i + 2)
                {

                    string tdinnertext = DeleteCrlfTabNbsp(tds[i].InnerText);
                    win_odds.Add(tdinnertext);
                }
                return win_odds;
            }
            else
            {
                List<string> win_odds = new List<string>();
                win_odds.Add("null");
                return win_odds;
            }


        }

        public static List<string> GetPlaceShowOdds(HtmlDocument htmldoc)
        {
            HtmlNode table = htmldoc.DocumentNode.SelectSingleNode("//html//table[@summary='単勝・複勝']");
            //HtmlNode table = htmldoc.DocumentNode.SelectSingleNode("/html[1]/body[1]/div[1]/div[3]/div[6]/div[1]/table[1]");
            HtmlNodeCollection tds = table.SelectNodes("//td[@class='al-center']");
            if (tds != null)
            {
                int count = tds.Count;

                // 複勝
                List<string> placeshow_odds = new List<string>();
                for (int i = 1; i < count; i = i + 2)
                {

                    string tdinnertext = DeleteCrlfTabNbsp(tds[i].InnerText);
                    placeshow_odds.Add(tdinnertext);
                }
                return placeshow_odds;
            }

            else
            {
                List<string> placeshow_odds = new List<string>();
                placeshow_odds.Add("null");
                return placeshow_odds;
            }
            

        }

        public static List<string> GetBracketQuinellaOdds(HtmlDocument htmldoc)
        {
            HtmlNode table = htmldoc.DocumentNode.SelectSingleNode("//html//table[@summary='枠複']");
            //HtmlNode table = htmldoc.DocumentNode.SelectSingleNode("/html[1]/body[1]/div[1]/div[3]/div[6]/div[1]/table[1]");
            HtmlNodeCollection tdbqs = table.SelectNodes("//td[@class='w75px al-right' or @class='w75px al-right del']");
            int count = tdbqs.Count;

            List<string> bracketquinella_odds = new List<string>();
            // TODO: 枠連
            for (int i = 0; i < count; i++)
            {
                string tdbqinnertext = DeleteCrlfTabNbsp(tdbqs[i].InnerText);

                    bracketquinella_odds.Add(tdbqinnertext);
                
            }

            /*
            HtmlNodeCollection td77 = table.SelectNodes("//td[@class='w75px al-right del']");
            if (td77 != null)
            {
                bracketquinella_odds.Insert(29, "null");
            }*/
            

            return bracketquinella_odds;
        }

        public static List<string> GetBracketExactaOdds(HtmlDocument htmldoc)
        {
            List<string> bracketexacta_odds = new List<string>();
            // TODO: 枠単
            return bracketexacta_odds;
        }

        public static List<string> GetQuinellaOdds(HtmlDocument htmldoc)
        {
            List<string> quinella_odds = new List<string>();
            // TODO: 馬連
            return quinella_odds;
        }

        public static List<string> GetExactaOdds(HtmlDocument htmldoc)
        {
            List<string> exacta_odds = new List<string>();
            // TODO: 馬単
            return exacta_odds;
        }

        public static List<string> GetQuinellaPlaceOdds(HtmlDocument htmldoc)
        {
            List<string> quinellaplace_odds = new List<string>();
            // TODO: ワイド
            // http://en.wikipedia.org/wiki/Parimutuel_betting#Japan
            return quinellaplace_odds;
        }

        public static List<string> GetTrioOdds(HtmlDocument htmldoc)
        {
            List<string> trio_odds = new List<string>();
            // TODO: 3連複
            return trio_odds;
        }

        public static List<string> GetTrifectaOdds(HtmlDocument htmldoc)
        {
            List<string> trifecta_odds = new List<string>();
            // TODO: 3連単
            return trifecta_odds;
        }

        private static string DeleteCrlfTabNbsp(string innertxt)
        {
            return innertxt.Replace("\n", "").Replace("\t", "").Replace(" ", "").Replace("&nbsp;", "");
        }
    }
}
