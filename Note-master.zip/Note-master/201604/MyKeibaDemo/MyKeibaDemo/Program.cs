﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace MyKeibaDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("比赛日期: 20141201, 20141202");
            Console.WriteLine("马场: 帯広, 水沢, 金沢, 名古屋, 園田");
            Console.WriteLine("请等待18秒左右……");

            // 帯広 opTrackCd=03&sponsorCd=04
            // 水沢 opTrackCd=12&sponsorCd=06

            // 金沢 opTrackCd=41&sponsorCd=18
            // 名古屋 opTrackCd=43&sponsorCd=33
            // 園田 opTrackCd=51&sponsorCd=26

            CExcelService.CreateCsvFiles("20141201", "03", "04");
            CExcelService.CreateCsvFiles("20141201", "12", "06");

            CExcelService.CreateCsvFiles("20141202", "41", "18");
            CExcelService.CreateCsvFiles("20141202", "43", "33");
            CExcelService.CreateCsvFiles("20141202", "51", "26");

            Console.WriteLine("按任意键结束...");
            Console.ReadKey();
        }
    }
}
