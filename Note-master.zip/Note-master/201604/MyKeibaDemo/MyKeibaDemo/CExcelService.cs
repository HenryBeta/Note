﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace MyKeibaDemo
{
    class CExcelService
    {
        // TODO
        public static void CreateCsvFiles(string race_day, string operation_track_code, string sponsor_code)
        {
            
            string p1data = OperationTrack.CatchWinData(race_day, operation_track_code, sponsor_code);
            Console.Write(p1data);
            Console.WriteLine("开始写入" + race_day + operation_track_code + "P1表...");
            string path1 = race_day + operation_track_code + "P1.csv";
            using (StreamWriter writer = File.CreateText(path1))
            {
                writer.Write(p1data);
            }
            Console.WriteLine(race_day + operation_track_code + "P1表完成");

            
            string p2data = OperationTrack.CatchPlaceShowData(race_day, operation_track_code, sponsor_code);
            Console.Write(p2data);
            Console.WriteLine("开始写入" + race_day + operation_track_code + "P2表...");
            string path2 = race_day + operation_track_code + "P2.csv";
            using (StreamWriter writer = File.CreateText(path2))
            {
                writer.Write(p2data);
            }
            Console.WriteLine(race_day + operation_track_code + "P2表完成");

          
            
            string p3data = OperationTrack.CatchBracketQuinellaData(race_day, operation_track_code, sponsor_code);
            Console.Write(p3data);
            Console.WriteLine("开始写入" + race_day + operation_track_code + "P3表...");
            string path3 = race_day + operation_track_code + "P3.csv";
            using (StreamWriter writer = File.CreateText(path3))
            {
                writer.Write(p3data);
            }
            Console.WriteLine(race_day + operation_track_code + "P3表完成");
        }
    }
}
