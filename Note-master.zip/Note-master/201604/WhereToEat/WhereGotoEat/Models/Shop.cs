﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WhereGotoEat.Models
{
    public class Shop
    {
        public string id { get; set; }
        public string img { get; set; }
        public string title { get; set; }
        public string rank { get; set; }
        public string price { get; set; }
        public string tag { get; set; }
        public string region { get; set; }
        public string addr { get; set; }
        public string kouwei { get; set; }
        public string huanjing { get; set; }
        public string fuwu { get; set; }
        public string svrinfo { get; set; }
    }
}