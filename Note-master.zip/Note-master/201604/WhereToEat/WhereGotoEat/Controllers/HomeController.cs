﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace WhereGotoEat.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        [OutputCache(Duration=864000, VaryByParam="none")]
        public ActionResult Index()
        {
            Uri uri = new Uri("http://www.dianping.com/search/category/1/10");
            HttpWebRequest http_request = (HttpWebRequest) WebRequest.Create(uri);
            http_request.Method = "GET";
            http_request.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0";

            HttpWebResponse http_response = (HttpWebResponse) http_request.GetResponse();

            string html = new StreamReader(http_response.GetResponseStream(), Encoding.UTF8).ReadToEnd();

            HtmlAgilityPack.HtmlDocument html_doc = new HtmlAgilityPack.HtmlDocument();
            html_doc.LoadHtml(html);

            HtmlAgilityPack.HtmlNodeCollection classfy_nodes = html_doc.DocumentNode.SelectNodes("//html/body//div[@id='classfy']/a");
            HtmlAgilityPack.HtmlNodeCollection region_nodes = html_doc.DocumentNode.SelectNodes("//html/body//div[@id='region-nav']/a");

            ViewBag.Classes = new Dictionary<int, string>();
            ViewBag.Regions = new Dictionary<int, string>();

            foreach (var item in classfy_nodes)
            {
                string url = item.Attributes["href"].Value;
                string num = url.Substring(23);
                int key = Int32.Parse(num);

                string value = item.InnerText;

                ViewBag.Classes.Add(key, value);
            }

            foreach (var item in region_nodes)
            {
                string url = item.Attributes["href"].Value;
                string[] split = url.Split('#');
                string num = split[0].Substring(23);
                int key = Int32.Parse(num);

                string value = item.InnerText;

                ViewBag.Regions.Add(key, value);
            }

            return View();
        }

    }
}
