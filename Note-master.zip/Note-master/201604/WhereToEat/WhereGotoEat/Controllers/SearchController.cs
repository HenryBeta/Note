﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using WhereGotoEat.Models;

namespace WhereGotoEat.Controllers
{
    public class SearchController : Controller
    {
        //
        // GET: /Search/

        public ActionResult Index()
        {
            string keyword = Request.QueryString["keyword"];
            string g = Request.QueryString["g"];
            string r = Request.QueryString["r"];
            string x = Request.QueryString["x"];
            string y = Request.QueryString["y"];
            string p = Request.QueryString["p"];

            string url = "http://www.dianping.com/search/category/1/10/";

            if (String.IsNullOrEmpty(keyword))
            {
                if (String.IsNullOrEmpty(x) || String.IsNullOrEmpty(y))
                {
                    url = "http://www.dianping.com/search/category/1/10/" + "g" + g + "r" + r;
                }
                else
                {
                    url = "http://www.dianping.com/search/category/1/10/" + "g" + g + "r" + r + "x" + x + "y" + y;
                }
     
            }
            else
            {
                if (String.IsNullOrEmpty(x) || String.IsNullOrEmpty(y))
                {
                    url = "http://www.dianping.com/search/keyword/1/10_" + keyword + "/" + "g" + g + "r" + r;
                }
                else
                {
                    url = "http://www.dianping.com/search/keyword/1/10_" + keyword + "/" + "g" + g + "r" + r + "x" + x + "y" + y;
                }
            }

            if (!String.IsNullOrEmpty(p))
            {
                url = url + "p" + p; 
            }

            //ViewBag.MyUrl = url;
                
            Uri uri = new Uri(url);
            HttpWebRequest http_request = (HttpWebRequest)WebRequest.Create(uri);
            http_request.Method = "GET";
            http_request.UserAgent = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0";

            HttpWebResponse http_response = (HttpWebResponse)http_request.GetResponse();

            string html = new StreamReader(http_response.GetResponseStream(), Encoding.UTF8).ReadToEnd();

            HtmlAgilityPack.HtmlDocument html_doc = new HtmlAgilityPack.HtmlDocument();
            html_doc.LoadHtml(html);

            HtmlAgilityPack.HtmlNode list_div = html_doc.DocumentNode.SelectSingleNode("//html/body//div[@id='shop-all-list']");

            StringBuilder sb = new StringBuilder();
            sb.Append("<html>");
            sb.Append(list_div.OuterHtml);
            sb.Append("</html>");

            HtmlAgilityPack.HtmlDocument new_html_doc = new HtmlAgilityPack.HtmlDocument();
            new_html_doc.LoadHtml(sb.ToString());

            HtmlAgilityPack.HtmlNodeCollection li_nodes = new_html_doc.DocumentNode.SelectNodes("//li");
            List<string> lis = new List<string>();
            for (int i = 0; i < li_nodes.Count; i++)
            {
                StringBuilder li_html = new StringBuilder();
                li_html.Append("<html>");
                li_html.Append(li_nodes[i].InnerHtml);
                li_html.Append("</html>");
                lis.Add(li_html.ToString());
            }

            List<Shop> shops = new List<Shop>();
            //ViewBag.Urls = new List<string>();

            foreach (string li in lis)
            {
                Shop shop = new Shop();
                HtmlAgilityPack.HtmlDocument li_doc = new HtmlAgilityPack.HtmlDocument();
                li_doc.LoadHtml(li);

                string shop_url = li_doc.DocumentNode.SelectSingleNode("//html/div[1]/a").Attributes["href"].Value;
                shop.id = shop_url;

                string img_url = li_doc.DocumentNode.SelectSingleNode("//html/div[1]//img").Attributes["data-src"].Value;
                //ViewBag.Urls.Add(img_url);
                shop.img = img_url;

                string title = li_doc.DocumentNode.SelectSingleNode("//html/div[1]//img").Attributes["title"].Value;
                shop.title = title;

                string addr = li_doc.DocumentNode.SelectSingleNode("//html/div[2]/div[3]/span").InnerText;
                shop.addr = addr;

                string tag = li_doc.DocumentNode.SelectSingleNode("//html/div[2]/div[3]/a[1]/span").InnerText;
                shop.tag = tag;

                string region = li_doc.DocumentNode.SelectSingleNode("//html/div[2]/div[3]/a[2]/span").InnerText;
                shop.region = region;

                HtmlNode pricenode = li_doc.DocumentNode.SelectSingleNode("//html/div[2]/div[2]/a[2]/b");

                if (pricenode!= null)
                {
                    string price = pricenode.InnerText;
                    shop.price = price;
                }
                // string price = li_doc.DocumentNode.SelectSingleNode("//html/div[2]/div[2]/a[2]/b").InnerText;
                // shop.price = price;

                string kouwei = li_doc.DocumentNode.SelectSingleNode("//html/div[2]/span/span[1]/b").InnerText;
                shop.kouwei = kouwei;

                string huanjing = li_doc.DocumentNode.SelectSingleNode("//html/div[2]/span/span[2]/b").InnerText;
                shop.huanjing = huanjing;

                string fuwu = li_doc.DocumentNode.SelectSingleNode("//html/div[2]/span/span[3]/b").InnerText;
                shop.fuwu = fuwu;

                string rank = li_doc.DocumentNode.SelectSingleNode("//html/div[2]/div[2]/span").Attributes["title"].Value;
                shop.rank = rank;

                HtmlNode info = li_doc.DocumentNode.SelectSingleNode("//html/div[@class='svr-info']/a[1]");
                if (info != null)
                {
                    string svrinfo = info.Attributes["title"].Value;
                    shop.svrinfo = svrinfo;
                }
                else
                {
                    shop.svrinfo = "暂无";
                }

                shops.Add(shop);
            }

            return View(shops);
        }

        public void getimg()
        {
            string html = "";
            string pattern = @"\bdata-src=\S*thumb\.jpg\b";
            Regex regex = new Regex(pattern, RegexOptions.IgnoreCase);
            MatchCollection matches = regex.Matches(html);

            ViewBag.Urls = new List<string>();

            foreach (Match match in matches)
            {
                string img_url = match.Value.TrimStart("data-src=\"".ToCharArray());
                ViewBag.Urls.Add(img_url);
            }
        }

    }
}
