# MyStore

Starting ActiveMQ On Windows <br>
1 cd [activemq_install_dir] <br>
2 bin\activemq start
  or bin\activemq <br>
  
  错误: 找不到或无法加载主类 ActiveMQ\bin\..\conf\login.config <br>
  在执行命令行输入参数的时候，如果字符串参数中包括空格就必须用双引号引住。<br>
  
  
http://localhost:8161/admin
The default username and password is admin/admin.
